

class ToDo {
  int id;
  String? todoText;
  String? created_at;
  bool isDone;

  ToDo({
    required this.id,
    required this.todoText,
    required this.created_at,
    this.isDone = false,
  });

  static List<ToDo> todoList() {
    return [

    ];
  }
}