import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:intl/intl.dart';

import '../applocale/applocale.dart';
import '../model/todo.dart';

class localization extends StatelessWidget {
  const localization({super.key});

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return const MaterialApp(
      localizationsDelegates: [
        AppLocale.delegate,
        GlobalMaterialLocalizations.delegate,
        GlobalWidgetsLocalizations.delegate
      ],
      supportedLocales: [
        Locale("en", "EN"),
        Locale("ar", "AR"),
      ],
    );
  }
}

class CompletedTasksScreen extends StatefulWidget {
  final List<ToDo> completedTasks;

  const CompletedTasksScreen({super.key, required this.completedTasks});

  @override
  State<CompletedTasksScreen> createState() => _CompletedTasksScreenState();
}

class _CompletedTasksScreenState extends State<CompletedTasksScreen> {
  final todosList = ToDo.todoList();



  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey[300],
      appBar: _buildAppBar(),
      body: _buildBody(),
    );
  }

  Widget _buildBody() {
    return Stack(
        children: [
          Expanded(
            child: ListView(
              children: [
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 15),
                  child: Text("${getLang(context, "CompletedTask")}",
                    style: const TextStyle(
                      fontSize: 25,
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                ),
              ],
            ),
          ),
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 10,),
          margin: const EdgeInsets.only(
            top: 60,
            bottom: 20,
          ),
          child: ListView.builder(
            itemCount: widget.completedTasks.length,
            itemBuilder: (context, index) {
              final todo = widget.completedTasks[index];
              return ListTile(
                title: Text(
                  todo.todoText!,
                ),
                subtitle: Text(
                  DateFormat('yyyy-MM-dd - h:mm a').format(DateTime.parse(todo.created_at!)),
                ),
              );
            },
          ),
        ),
    ]);
  }

  AppBar _buildAppBar() {
    return AppBar(
      backgroundColor: Colors.grey[300],
      elevation: 0,
      title: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            SizedBox(
              height: 40,
              width: 40,
              child: ClipRRect(
                borderRadius: BorderRadius.circular(30),
                child: Image.asset('assets/images/man.png'),
              ),
            ),
          ]),
    );
  }
}